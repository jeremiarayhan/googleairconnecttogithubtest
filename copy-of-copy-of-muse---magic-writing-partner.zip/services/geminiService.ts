
import { GoogleGenAI, Type } from "@google/genai";
import { Attachment, WritingBlock } from "../types";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateInitialDraft = async (prompt: string, attachments: Attachment[]): Promise<string> => {
  const ai = getAI();
  const parts: any[] = [{ text: prompt }];

  attachments.forEach(att => {
    parts.push({
      inlineData: {
        mimeType: att.type,
        data: att.base64
      }
    });
  });

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: { parts },
    config: {
      systemInstruction: `You are an elite ghostwriter and thought partner. 
      Generate a high-quality initial draft based on the prompt and attachments. 
      Format the output clearly with paragraphs. Do not use markdown headers unless explicitly asked.
      Focus on a compelling narrative and clear structure.`
    }
  });

  return response.text || "I couldn't generate a draft. Please try a different prompt.";
};

export const iterateOnSelection = async (
  context: string, 
  selection: string, 
  instruction: string
): Promise<string> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `
      Context of the writing: "${context}"
      Specific section to edit: "${selection}"
      Instruction: "${instruction}"
      
      Rewrite only the specific section to better match the instruction while keeping the context. 
      Return ONLY the rewritten text.
    `,
    config: {
      systemInstruction: "You are a precise editor. Follow instructions exactly and only return the changed text."
    }
  });

  return response.text || selection;
};

export const getProactiveFeedback = async (content: string): Promise<any> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze this writing: "${content}"`,
    config: {
      systemInstruction: "You are a proactive writing coach. If you see a way to significantly improve a specific part (clarity, punchiness, tone), provide a short suggestion. If the writing is good, return nothing.",
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          hasSuggestion: { type: Type.BOOLEAN },
          targetSnippet: { type: Type.STRING, description: "The exact snippet to improve" },
          suggestion: { type: Type.STRING, description: "The improved version" },
          reason: { type: Type.STRING, description: "Why this is better" }
        },
        required: ["hasSuggestion"]
      }
    }
  });

  try {
    return JSON.parse(response.text || "{}");
  } catch (e) {
    return { hasSuggestion: false };
  }
};

export const generateCommitMessage = async (content: string): Promise<string> => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Summarize the changes in this writing into a concise, professional commit message (max 50 chars): "${content.substring(0, 1000)}"`,
    config: {
      systemInstruction: "You are a version control assistant. Generate a brief, meaningful commit message based on the writing content provided."
    }
  });
  return response.text?.replace(/["']/g, '').trim() || "Updated draft content";
};
