
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { WritingBlock, Attachment, Suggestion, Commit, Branch } from './types';
import * as aiService from './services/geminiService';
import { 
  Plus, 
  Send, 
  Sparkles, 
  FileUp, 
  X, 
  ChevronRight, 
  RefreshCw, 
  Check, 
  Trash2, 
  MessageSquarePlus,
  ArrowRight,
  Github,
  CloudUpload,
  History,
  GitBranch,
  GitCommit,
  Edit2,
  ExternalLink,
  Terminal
} from 'lucide-react';

const REPO_URL = "https://github.com/jeremiarayhan/googleairconnecttogithubtest.git";

const App: React.FC = () => {
  const [blocks, setBlocks] = useState<WritingBlock[]>([]);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isInitialState, setIsInitialState] = useState(true);
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedText, setSelectedText] = useState<{ text: string, blockId: string } | null>(null);
  const [activeSuggestion, setActiveSuggestion] = useState<Suggestion | null>(null);
  const [instruction, setInstruction] = useState('');
  const [isIterating, setIsIterating] = useState(false);
  
  // GitHub & Branching State
  const [commits, setCommits] = useState<Commit[]>([]);
  const [branches, setBranches] = useState<Branch[]>([
    { name: 'main', blocks: [], lastUpdated: Date.now() }
  ]);
  const [currentBranchName, setCurrentBranchName] = useState('main');
  const [showBranchModal, setShowBranchModal] = useState(false);
  const [newBranchName, setNewBranchName] = useState('');
  
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStage, setSyncStage] = useState<'idle' | 'connecting' | 'pushing' | 'success'>('idle');
  const [showSyncModal, setShowSyncModal] = useState(false);
  const [commitMessage, setCommitMessage] = useState('');
  const [isGeneratingMessage, setIsGeneratingMessage] = useState(false);

  // Sync current blocks to the branch state whenever blocks change
  useEffect(() => {
    if (!isInitialState) {
      setBranches(prev => prev.map(b => 
        b.name === currentBranchName 
          ? { ...b, blocks: [...blocks], lastUpdated: Date.now() } 
          : b
      ));
    }
  }, [blocks, currentBranchName, isInitialState]);

  const handleStartWriting = async () => {
    if (!prompt.trim() && attachments.length === 0) return;
    setIsGenerating(true);
    try {
      const draft = await aiService.generateInitialDraft(prompt, attachments);
      const newBlocks = draft.split('\n\n').filter(p => p.trim()).map(p => ({
        id: Math.random().toString(36).substr(2, 9),
        content: p.trim()
      }));
      setBlocks(newBlocks);
      setIsInitialState(false);
      setBranches([{ name: 'main', blocks: newBlocks, lastUpdated: Date.now() }]);
    } catch (err) {
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    (Array.from(files) as File[]).forEach(file => {
      const reader = new FileReader();
      reader.onload = (readerEvent) => {
        const base64 = (readerEvent.target?.result as string).split(',')[1];
        setAttachments(prev => [...prev, {
          id: Math.random().toString(36).substr(2, 9),
          name: file.name,
          type: file.type,
          base64: base64
        }]);
      };
      reader.readAsDataURL(file);
    });
  };

  const handleSelection = useCallback(() => {
    const selection = window.getSelection();
    if (selection && selection.toString().trim().length > 0) {
      const range = selection.getRangeAt(0);
      let container = range.commonAncestorContainer as any;
      while (container && !container.dataset?.blockid) {
        container = container.parentElement;
      }
      if (container && container.dataset.blockid) {
        setSelectedText({
          text: selection.toString(),
          blockId: container.dataset.blockid
        });
      }
    } else {
      setSelectedText(null);
    }
  }, []);

  const handleIteration = async () => {
    if (!selectedText || !instruction.trim()) return;
    setIsIterating(true);
    try {
      const block = blocks.find(b => b.id === selectedText.blockId);
      const context = blocks.map(b => b.content).join('\n\n');
      const rewritten = await aiService.iterateOnSelection(context, selectedText.text, instruction);
      if (block) {
        setBlocks(prev => prev.map(b => {
          if (b.id === block.id) {
            return { ...b, content: b.content.replace(selectedText.text, rewritten) };
          }
          return b;
        }));
      }
      setSelectedText(null);
      setInstruction('');
    } catch (err) {
      console.error(err);
    } finally {
      setIsIterating(false);
    }
  };

  const handleUpdateBlock = (id: string, newContent: string) => {
    setBlocks(prev => prev.map(b => b.id === id ? { ...b, content: newContent } : b));
  };

  const createBranch = () => {
    if (!newBranchName.trim()) return;
    const exists = branches.find(b => b.name === newBranchName);
    if (exists) {
      alert("Branch already exists");
      return;
    }
    const newBranch: Branch = {
      name: newBranchName,
      blocks: [...blocks],
      lastUpdated: Date.now()
    };
    setBranches([...branches, newBranch]);
    setCurrentBranchName(newBranchName);
    setNewBranchName('');
    setShowBranchModal(false);
  };

  const switchBranch = (name: string) => {
    const target = branches.find(b => b.name === name);
    if (target) {
      setCurrentBranchName(name);
      setBlocks([...target.blocks]);
      setShowBranchModal(false);
    }
  };

  const openSyncDialog = async () => {
    setSyncStage('idle');
    setShowSyncModal(true);
    setIsGeneratingMessage(true);
    try {
      const fullContent = blocks.map(b => b.content).join('\n\n');
      const message = await aiService.generateCommitMessage(fullContent);
      setCommitMessage(message);
    } finally {
      setIsGeneratingMessage(false);
    }
  };

  const handlePushToGithub = async () => {
    setIsSyncing(true);
    setSyncStage('connecting');
    await new Promise(resolve => setTimeout(resolve, 800));
    
    setSyncStage('pushing');
    await new Promise(resolve => setTimeout(resolve, 1200));
    
    const newCommit: Commit = {
      id: Math.random().toString(36).substr(2, 9),
      message: commitMessage,
      timestamp: Date.now(),
      content: blocks.map(b => b.content).join('\n\n')
    };
    
    setCommits([newCommit, ...commits]);
    setSyncStage('success');
    setIsSyncing(false);
    
    // Auto close after success
    setTimeout(() => {
      setShowSyncModal(false);
      setSyncStage('idle');
      setCommitMessage('');
    }, 2000);
  };

  useEffect(() => {
    if (isInitialState || blocks.length === 0) return;
    const timer = setTimeout(async () => {
      const fullText = blocks.map(b => b.content).join('\n\n');
      const feedback = await aiService.getProactiveFeedback(fullText);
      if (feedback.hasSuggestion) {
        const targetBlock = blocks.find(b => b.content.includes(feedback.targetSnippet));
        if (targetBlock) {
          setActiveSuggestion({
            id: Math.random().toString(36).substr(2, 9),
            blockId: targetBlock.id,
            originalText: feedback.targetSnippet,
            suggestedText: feedback.suggestion,
            reason: feedback.reason,
            status: 'pending'
          });
        }
      }
    }, 10000);
    return () => clearTimeout(timer);
  }, [blocks, isInitialState]);

  if (isInitialState) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-slate-50">
        <div className="w-full max-w-2xl bg-white rounded-3xl shadow-xl shadow-slate-200/50 p-8 border border-slate-100 animate-in fade-in zoom-in duration-500">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center">
              <Sparkles className="text-white w-6 h-6" />
            </div>
            <h1 className="text-2xl font-semibold text-slate-900 sans-text">Muse</h1>
          </div>
          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-600 sans-text">What are we writing today?</label>
              <textarea 
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="A blog post about the future of AI interfaces..."
                className="w-full min-h-[160px] p-4 text-lg bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none resize-none sans-text"
              />
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between sans-text">
                <label className="text-sm font-medium text-slate-600">Attachments</label>
                <label className="cursor-pointer group flex items-center gap-2 text-indigo-600 hover:text-indigo-700 transition-colors">
                  <FileUp className="w-4 h-4" />
                  <span className="text-sm font-medium">Add Files</span>
                  <input type="file" multiple onChange={handleFileUpload} className="hidden" />
                </label>
              </div>
              <div className="flex flex-wrap gap-2">
                {attachments.map(att => (
                  <div key={att.id} className="flex items-center gap-2 bg-slate-100 px-3 py-1.5 rounded-full border border-slate-200">
                    <span className="text-xs font-medium text-slate-700 truncate max-w-[150px]">{att.name}</span>
                    <button onClick={() => setAttachments(prev => prev.filter(a => a.id !== att.id))}>
                      <X className="w-3.5 h-3.5 text-slate-400 hover:text-red-500" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
            <button 
              onClick={handleStartWriting}
              disabled={isGenerating || (!prompt && attachments.length === 0)}
              className="w-full py-4 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-300 text-white rounded-2xl font-medium flex items-center justify-center gap-2 transition-all transform active:scale-[0.98] sans-text"
            >
              {isGenerating ? <RefreshCw className="w-5 h-5 animate-spin" /> : <ArrowRight className="w-5 h-5" />}
              {isGenerating ? "Generating draft..." : "Start Writing"}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white text-slate-900 serif-text selection:bg-indigo-100 selection:text-indigo-900" onMouseUp={handleSelection}>
      <header className="fixed top-0 left-0 right-0 h-16 bg-white/80 backdrop-blur-md border-b border-slate-100 flex items-center justify-between px-8 z-50">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 cursor-pointer group" onClick={() => { setBlocks([]); setIsInitialState(true); }}>
            <Sparkles className="w-5 h-5 text-indigo-600 group-hover:rotate-12 transition-transform" />
            <span className="font-semibold text-slate-900 sans-text tracking-tight">Muse</span>
          </div>
          
          <div className="flex items-center gap-1 sans-text">
            <button 
              onClick={() => setShowBranchModal(true)}
              className="flex items-center gap-2 px-3 py-1.5 hover:bg-slate-100 rounded-lg transition-colors group"
            >
              <GitBranch className="w-4 h-4 text-slate-400 group-hover:text-indigo-600" />
              <span className="text-sm font-semibold text-slate-600">{currentBranchName}</span>
              <ChevronRight className="w-3 h-3 text-slate-300 rotate-90" />
            </button>
          </div>
        </div>

        <div className="flex items-center gap-4 sans-text">
          <div className="hidden md:flex items-center gap-2 px-3 py-1 bg-slate-50 border border-slate-100 rounded-full text-[10px] font-bold text-slate-400 uppercase tracking-tight">
            <Github className="w-3 h-3" />
            <span className="max-w-[120px] truncate">{REPO_URL.split('/').pop()?.replace('.git', '')}</span>
          </div>
          <button 
            onClick={openSyncDialog}
            className={`p-2 transition-colors relative ${commits.length > 0 && syncStage === 'idle' ? 'text-indigo-600' : 'text-slate-500 hover:text-indigo-600'}`}
            title="Sync to GitHub"
          >
            <CloudUpload className="w-5 h-5" />
            {commits.length > 0 && <span className="absolute top-1 right-1 w-2 h-2 bg-indigo-500 rounded-full border-2 border-white"></span>}
          </button>
          <div className="h-4 w-px bg-slate-200"></div>
          <button 
            onClick={() => { if(confirm('Start new draft?')) { setBlocks([]); setIsInitialState(true); setAttachments([]); setPrompt(''); } }}
            className="text-sm font-medium text-slate-400 hover:text-slate-900"
          >
            Reset
          </button>
        </div>
      </header>

      <main className="max-w-3xl mx-auto pt-32 pb-64 px-6 relative">
        <div className="space-y-8">
          {blocks.map((block) => (
            <div key={block.id} className="group relative" data-blockid={block.id}>
              <div 
                contentEditable
                suppressContentEditableWarning
                onBlur={(e) => handleUpdateBlock(block.id, e.currentTarget.textContent || '')}
                className="text-xl leading-relaxed text-slate-800 outline-none border-l-2 border-transparent hover:border-slate-100 focus:border-indigo-400 pl-4 py-1"
              >
                {block.content}
              </div>
              {activeSuggestion?.blockId === block.id && (
                <div className="absolute -left-12 top-2 p-2 rounded-full bg-indigo-50 text-indigo-600 animate-bounce cursor-pointer" onClick={() => {}}>
                  <Sparkles className="w-5 h-5" />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Branch Modal */}
        {showBranchModal && (
          <div className="fixed inset-0 bg-slate-900/20 backdrop-blur-[2px] z-[100] flex items-center justify-center p-6" onClick={() => setShowBranchModal(false)}>
            <div className="w-full max-w-sm bg-white rounded-3xl shadow-2xl p-6 sans-text animate-in zoom-in duration-200" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2">
                  <GitBranch className="w-5 h-5 text-indigo-600" />
                  <h3 className="font-semibold text-slate-900">Thought Branches</h3>
                </div>
                <button onClick={() => setShowBranchModal(false)}><X className="w-5 h-5 text-slate-400" /></button>
              </div>

              <div className="space-y-4">
                <div className="space-y-2 max-h-48 overflow-y-auto no-scrollbar">
                  {branches.map(b => (
                    <button 
                      key={b.name}
                      onClick={() => switchBranch(b.name)}
                      className={`w-full flex items-center justify-between p-3 rounded-xl border transition-all ${currentBranchName === b.name ? 'border-indigo-600 bg-indigo-50 text-indigo-900' : 'border-slate-100 hover:border-slate-200 text-slate-600'}`}
                    >
                      <div className="flex items-center gap-3">
                        <GitCommit className={`w-4 h-4 ${currentBranchName === b.name ? 'text-indigo-600' : 'text-slate-300'}`} />
                        <span className="text-sm font-medium">{b.name}</span>
                      </div>
                      <span className="text-[10px] opacity-50">{new Date(b.lastUpdated).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                    </button>
                  ))}
                </div>

                <div className="pt-2">
                  <div className="flex gap-2">
                    <input 
                      value={newBranchName}
                      onChange={(e) => setNewBranchName(e.target.value.toLowerCase().replace(/\s/g, '-'))}
                      placeholder="Branch name (e.g. experimental)"
                      className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                      onKeyDown={e => e.key === 'Enter' && createBranch()}
                    />
                    <button 
                      onClick={createBranch}
                      disabled={!newBranchName.trim()}
                      className="bg-slate-900 text-white px-4 py-2.5 rounded-xl text-sm font-semibold disabled:bg-slate-200 transition-colors"
                    >
                      New
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Sync Modal / Git Push Interface */}
        {showSyncModal && (
          <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[100] flex items-center justify-center p-6" onClick={() => !isSyncing && setShowSyncModal(false)}>
            <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl p-6 sans-text animate-in zoom-in duration-200 overflow-hidden" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-2">
                  <Github className="w-5 h-5" />
                  <h3 className="font-semibold text-slate-900">Push to origin/{currentBranchName}</h3>
                </div>
                {!isSyncing && <button onClick={() => setShowSyncModal(false)}><X className="w-5 h-5 text-slate-400 hover:text-slate-600" /></button>}
              </div>
              
              <div className="space-y-4">
                {syncStage === 'idle' && (
                  <div className="space-y-4 animate-in fade-in slide-in-from-top-2">
                    <div className="space-y-1">
                      <div className="flex items-center justify-between">
                        <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Muse's Suggested Message</label>
                        {isGeneratingMessage && <RefreshCw className="w-3 h-3 animate-spin text-indigo-500" />}
                      </div>
                      <input 
                        value={commitMessage}
                        onChange={(e) => setCommitMessage(e.target.value)}
                        disabled={isGeneratingMessage}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-indigo-500 transition-all text-sm font-medium"
                      />
                    </div>

                    <div className="bg-slate-50 rounded-xl p-3 border border-slate-100">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-bold text-slate-400 uppercase">Status Summary</span>
                        <History className="w-3 h-3 text-slate-400" />
                      </div>
                      <div className="text-[11px] text-slate-600 space-y-1">
                        <div className="flex justify-between">
                          <span>Writing Blocks</span>
                          <span className="font-mono">{blocks.length}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Target Remote</span>
                          <span className="font-mono text-indigo-600 truncate max-w-[140px]">origin/{currentBranchName}</span>
                        </div>
                      </div>
                    </div>

                    <button 
                      onClick={handlePushToGithub}
                      disabled={isSyncing || !commitMessage.trim()}
                      className="w-full py-3.5 bg-slate-900 text-white rounded-xl font-semibold flex items-center justify-center gap-2 hover:bg-slate-800 transition-all active:scale-[0.98] disabled:bg-slate-200"
                    >
                      <CloudUpload className="w-4 h-4" />
                      Commit and Push
                    </button>
                  </div>
                )}

                {(syncStage === 'connecting' || syncStage === 'pushing') && (
                  <div className="py-8 space-y-6 animate-in fade-in zoom-in duration-300">
                    <div className="flex flex-col items-center justify-center gap-4">
                      <div className="relative">
                        <Github className="w-12 h-12 text-slate-900 animate-pulse" />
                        <div className="absolute -top-1 -right-1">
                          <RefreshCw className="w-5 h-5 text-indigo-500 animate-spin" />
                        </div>
                      </div>
                      <div className="text-center">
                        <p className="text-sm font-semibold text-slate-900">
                          {syncStage === 'connecting' ? 'Connecting to origin...' : `Pushing to ${currentBranchName}...`}
                        </p>
                        <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-widest font-mono">
                          git push -u origin {currentBranchName}
                        </p>
                      </div>
                    </div>
                    
                    <div className="w-full bg-slate-100 h-1 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-indigo-600 transition-all duration-1000" 
                        style={{ width: syncStage === 'connecting' ? '30%' : '70%' }}
                      ></div>
                    </div>

                    <div className="bg-slate-900 rounded-lg p-3 font-mono text-[10px] text-indigo-300 space-y-1 opacity-80">
                      <p className="text-white">> git remote add origin {REPO_URL.split('/').pop()}</p>
                      <p className="text-white">> git branch -M {currentBranchName}</p>
                      <p className={syncStage === 'pushing' ? 'text-indigo-400' : 'text-slate-500'}>
                        {syncStage === 'pushing' ? '> pushing objects...' : '> establishing connection...'}
                      </p>
                    </div>
                  </div>
                )}

                {syncStage === 'success' && (
                  <div className="py-8 space-y-4 text-center animate-in zoom-in duration-300">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <Check className="w-8 h-8 text-green-600" />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900">Successfully Pushed</h4>
                      <p className="text-sm text-slate-500 mt-1">Changes are live on {currentBranchName}</p>
                    </div>
                    <a 
                      href={REPO_URL.replace('.git', '')}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-xs font-semibold text-indigo-600 hover:text-indigo-700 mt-2 px-3 py-1.5 bg-indigo-50 rounded-lg transition-colors"
                    >
                      <ExternalLink className="w-3 h-3" /> View on GitHub
                    </a>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Floating Context Menu */}
        {selectedText && (
          <div className="fixed bottom-12 left-1/2 -translate-x-1/2 w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 p-4 sans-text z-[60] animate-in slide-in-from-bottom-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-indigo-600 uppercase tracking-wider">Iterate on selection</span>
                <button onClick={() => setSelectedText(null)}><X className="w-4 h-4 text-slate-400 hover:text-slate-600" /></button>
              </div>
              <input 
                autoFocus
                value={instruction}
                onChange={(e) => setInstruction(e.target.value)}
                placeholder="e.g., 'Make it more persuasive'"
                className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                onKeyDown={(e) => e.key === 'Enter' && handleIteration()}
              />
              <button 
                onClick={handleIteration}
                disabled={isIterating || !instruction.trim()}
                className="w-full bg-indigo-600 text-white py-2.5 rounded-xl font-medium hover:bg-indigo-700 transition-colors disabled:bg-slate-200 flex items-center justify-center gap-2"
              >
                {isIterating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Edit2 className="w-4 h-4" />}
                {isIterating ? "Applying..." : "Apply Instruction"}
              </button>
            </div>
          </div>
        )}

        {activeSuggestion && (
          <div className="fixed right-8 top-1/2 -translate-y-1/2 w-80 bg-white rounded-3xl shadow-2xl border border-indigo-100 p-6 sans-text z-40 animate-in slide-in-from-right-8">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-4 h-4 text-indigo-600" />
              <span className="text-sm font-semibold text-slate-800">Coach Insight</span>
              <button className="ml-auto" onClick={() => setActiveSuggestion(null)}><X className="w-4 h-4 text-slate-300 hover:text-slate-500" /></button>
            </div>
            <p className="text-xs text-slate-500 mb-4 font-medium leading-relaxed">{activeSuggestion.reason}</p>
            <div className="bg-indigo-50/50 rounded-xl p-3 border border-indigo-100/50 mb-4 italic text-sm text-indigo-900 serif-text">
              "{activeSuggestion.suggestedText}"
            </div>
            <div className="flex gap-2">
              <button onClick={() => { 
                setBlocks(prev => prev.map(b => b.id === activeSuggestion.blockId ? { ...b, content: b.content.replace(activeSuggestion.originalText, activeSuggestion.suggestedText) } : b));
                setActiveSuggestion(null);
              }} className="flex-1 py-2 bg-indigo-600 text-white text-sm font-semibold rounded-xl hover:bg-indigo-700 transition-colors">Apply</button>
              <button onClick={() => setActiveSuggestion(null)} className="px-4 py-2 border border-slate-200 text-slate-600 text-sm font-semibold rounded-xl hover:bg-slate-50 transition-colors">Ignore</button>
            </div>
          </div>
        )}
      </main>

      <footer className="fixed bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-white via-white to-transparent pointer-events-none z-30">
        <div className="max-w-3xl mx-auto flex items-center justify-center h-full pointer-events-auto">
          <div className="bg-slate-900 text-white px-6 py-3 rounded-full shadow-xl flex items-center gap-6 sans-text transition-all transform hover:translate-y-[-2px]">
            <button className="flex items-center gap-2 hover:text-indigo-300 transition-colors group" onClick={() => setBlocks([...blocks, { id: Math.random().toString(36).substr(2, 9), content: 'Continue writing...' }])}>
              <Plus className="w-4 h-4 group-hover:rotate-90 transition-transform" /> <span className="text-sm font-medium">Add Block</span>
            </button>
            <div className="h-4 w-px bg-slate-700"></div>
            <button 
              className="flex items-center gap-2 hover:text-indigo-300 transition-colors"
              onClick={async () => {
                const fullText = blocks.map(b => b.content).join('\n\n');
                const lastBlock = blocks[blocks.length-1];
                setIsGenerating(true);
                const nextPart = await aiService.iterateOnSelection(fullText, lastBlock.content, "Continue the story naturally for another paragraph.");
                setBlocks([...blocks, { id: Math.random().toString(36).substr(2, 9), content: nextPart }]);
                setIsGenerating(false);
              }}
            >
              <Sparkles className={`w-4 h-4 ${isGenerating ? 'animate-spin' : ''}`} /> <span className="text-sm font-medium">{isGenerating ? 'Thinking...' : 'Magic Continue'}</span>
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
