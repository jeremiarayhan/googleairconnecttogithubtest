
export interface Attachment {
  id: string;
  name: string;
  type: string;
  base64: string;
}

export interface WritingBlock {
  id: string;
  content: string;
  isDraft?: boolean;
}

export interface Suggestion {
  id: string;
  blockId: string;
  originalText: string;
  suggestedText: string;
  reason: string;
  status: 'pending' | 'accepted' | 'rejected';
}

export interface Commit {
  id: string;
  message: string;
  timestamp: number;
  content: string;
}

export interface Branch {
  name: string;
  blocks: WritingBlock[];
  lastUpdated: number;
}

export interface AIResponse {
  content: string;
  suggestions?: {
    blockId: string;
    text: string;
    reason: string;
  }[];
}
